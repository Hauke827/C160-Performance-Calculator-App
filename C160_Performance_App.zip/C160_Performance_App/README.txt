C-160 Transall Performance Calculator
=====================================
Installable Progressive Web App (PWA)
Based on AzurPoly Flight Manual Rev.13 §11

CHANGES IN THIS VERSION
-----------------------
• METAR tab removed
• Weight & Balance simplified: only Fuel + Cargo inputs
• Empty weight fixed at 30 000 kg
• Takeoff pitch trim estimate added (based on total weight)

HOW TO INSTALL
--------------

1. Unzip the folder
2. Open a terminal inside the folder and run:
   python -m http.server 8080
3. Open http://localhost:8080 in Chrome or Edge
4. Click “Install App” (or the browser install icon)

FEATURES
--------
• Weight & Balance (Fuel + Cargo) → TOW + Takeoff Trim
• Official speed tables (VR, V2, VAPP, VS)
• Takeoff performance (flaps 20°, with/without water-methanol)
• Landing performance (normal + short-field)
• Cruise TAS & fuel flow for standard N1 settings
• Works offline after install

UNITS
-----
Weight  → kg
Altitude → feet
Distance → meters

Note: Takeoff trim is an estimate – the manual does not publish a numerical trim table.
Always fine-tune the pitch trim wheel in the aircraft.
